package com.zzmax.article;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UniArticleApiApplicationTests {

    @Test
    void contextLoads() {
    }

}
